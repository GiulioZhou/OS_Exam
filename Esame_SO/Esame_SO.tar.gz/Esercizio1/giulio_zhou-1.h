#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include <grp.h>
#include <pwd.h>


extern int checkgroup(const char* user, const char* group);
